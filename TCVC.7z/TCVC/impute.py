import numpy as np
from torch import optim, nn

from util import mv_dataset, read_mymat, build_ad_dataset, process_data, get_validation_set, \
    mv_tabular_collate
from scipy.spatial.distance import cdist
from model import VTN
import torch

reg_param = 1e-3


def get_samples(x, y, sn, test_index, n_sample, seed, device, trans_model ):
    """
    Retrieve the set of the k nearest samples with missing data on the training dataset.
    :param x: dataset: view_num * (dataset_num, dim,)
    :param y: label: (dataset_num,)
    :param sn: missing index matrix: (dataset_num, view_num,)
    :param train_index: (train_num,)
    :param test_index: (test_num,)
    :param n_sample: sampling frequency
    :param k: number of neighbors
    :return:
    """

    view_num = len(x)
    dismiss_view_index = [[np.array([]) for __ in range(view_num)] for _ in range(view_num)]
    for i in range(view_num - 1):
        for j in range(i + 1, view_num):
            sn_temp = sn[:, [i, j]]
            sn_temp_sum = np.sum(sn_temp, axis=1)
            sn_temp_sum[test_index] = 0  # Mask the test set sample
            dismiss_view_index[i][j] = dismiss_view_index[j][i] = np.where(sn_temp_sum == 2)[
                0]  # Sample index that exists in both views i and j

    print("Fill the missing views")
    sn_test = sn[test_index]
    x_test_dissmiss_index = np.where(np.sum(sn_test, axis=1) == view_num)[0]

    # impute missing views with all of the multiple sampling points
    x_test = [np.repeat(x[_][test_index][x_test_dissmiss_index], n_sample, axis=0) for _ in range(view_num)]
    y_test = np.repeat(y[test_index][x_test_dissmiss_index], n_sample, axis=0)

    z = 0
    count = np.sum(sn_test, axis=1)
    for i in test_index.flat:
        # view_num * (n_sample, dim,)
        x_i = [np.repeat(np.expand_dims(x[_][i], axis=0), n_sample, axis=0) for _ in range(view_num)]

        if count[z] < view_num:
            trans_xi = [np.repeat(np.expand_dims(x[_][i], axis=0), view_num, axis=0) for _ in range(view_num)]
            trans_xi_tensor = [torch.from_numpy(x).to(device) for x in trans_xi]
        z = z + 1

        # (n_sample, 1,)
        y_i = np.repeat(np.expand_dims(y[i], axis=0), n_sample, axis=0)

        sn_temp = sn[i]
        x_miss_view_index = np.nonzero(sn_temp == 0)[0]
        x_dismiss_view_index = np.nonzero(sn_temp)[0]

        # incomplete samples
        if x_miss_view_index.shape[0] != 0:
            for j in x_miss_view_index.flat:
                for jj in x_dismiss_view_index.flat:

                    if count[z - 1] < view_num:
                        trans_x_miss_view = trans_model(jj,jj * view_num + j, trans_xi_tensor[jj])
                        trans_xi[j][jj] = trans_x_miss_view.cpu().detach().numpy()[0]

                x_trans_temp = trans_xi[j]
                mean = np.mean(x_trans_temp, axis=0)
                cov = np.cov(x_trans_temp, rowvar=0)

                rng = np.random.default_rng(seed)
                cov = cov + np.eye(len(cov)) * reg_param
                L = np.linalg.cholesky(cov)
                x_samples_temp = rng.normal(size=(n_sample, len(cov))) @ L.T + mean
                x_i[j] = x_samples_temp


            x_test = [np.concatenate((x_test[_], x_i[_]), axis=0) for _ in range(view_num)]
            y_test = np.concatenate((y_test, y_i), axis=0)

    x_test = process_data(x_test, view_num)

    return x_test, y_test

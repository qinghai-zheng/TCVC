import numpy as np
from scipy.spatial.distance import cdist

def select_top_k_neighbors(x, y, k):
    """
    选取每个样本的前k个邻居样本，仅在同类标签样本中选择。

    参数:
    - x: 数据集，每个视图的数据表示，形状为 view_num * (dataset_num, dim,)。
    - y: 标签数组，形状为 (dataset_num,)。
    - dist_all_set: 每个视图的距离矩阵列表。
    - k: 邻居数量。

    返回:
    - neighbors: 每个样本在同类标签样本中的前k个邻居样本，形状为 view_num * (dataset_num, k)。
    """
    view_num = len(x)
    data_num = x[0].shape[0]
    x = [x_i.cpu().numpy() for x_i in x]
    y = y.cpu().numpy()
    dist_all_set = [cdist(x[i], x[i], 'euclidean') for i in range(view_num)]
    neighbors = []
    for view in range(view_num):
        view_neighbors = np.zeros((data_num, k), dtype=int)
        for i in range(data_num):
            # 获取当前样本的标签
            label = y[i]
            # 找到所有同类标签的样本
            same_class_indices = np.where(y == label)[0]
            # 排除自己
            same_class_indices = same_class_indices[same_class_indices != i]
            if same_class_indices.size == 0:
                continue
            # 获取当前样本在同类标签样本中的距离
            dist_temp = np.full(data_num, np.inf)
            dist_temp[same_class_indices] = dist_all_set[view][i, same_class_indices]
            # 选取前k个最近邻
            k_temp = min(k, len(same_class_indices))
            nearest_index_temp = np.argpartition(dist_temp, k_temp)[:k_temp]
            view_neighbors[i] = nearest_index_temp
        neighbors.append(view_neighbors)
    return neighbors

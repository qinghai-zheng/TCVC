import os
import numpy as np
import torch.optim as optim
from torch.autograd import Variable
from torch.utils.data import DataLoader
from model import *
from util import setup_seed, mv_dataset, read_mymat, build_ad_dataset, process_data, \
    mv_tabular_collate, partial_mv_dataset, partial_mv_tabular_collate
import warnings
from EarlyStopping_hand import EarlyStopping
from collections import Counter
from impute import get_samples
import csv
from select_top_k_neighbors import *

warnings.filterwarnings("ignore")
os.environ["CUDA_VISIBLE_DEVICES"] = "0"


class AverageMeter(object):
    """Computes and stores the average and current value"""

    def __init__(self):
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count


def load_data(dataset):
    if dataset == "BRAC":
        dims = [1000, 1000, 503]
        classifier_dims = [[1000], [1000], [503]]
        view = 3
        class_num = 5
    elif dataset == "Caltech101-20":
        dims = [48, 40, 254, 1984, 512, 928]
        classifier_dims = [[48], [40], [254], [1984], [512], [928]]
        view = 6
        class_num = 20
    elif dataset == "Animal":
        dims = [2689, 2000, 2001, 2000]
        classifier_dims = [[2689], [2000], [2001], [2000]]
        view = 4
        class_num = 20
    elif dataset == "ROSMAP":
        dims = [200, 200, 200]
        classifier_dims = [[200], [200], [200]]
        view = 3
        class_num = 2
    elif dataset == "my_UCI":
        dims = [240, 76, 6]
        classifier_dims = [[240], [76], [6]]
        view = 3
        class_num = 10
    elif dataset == "my_COIL20":
        dims = [1024, 944, 4096]
        classifier_dims = [[1024], [944], [4096]]
        view = 3
        class_num = 20
    elif dataset == "scene15":
        dims = [1800, 1180, 1240]
        classifier_dims = [[1800], [1180], [1240]]
        view = 3
        class_num = 15
    else:
        raise NotImplementedError
    return classifier_dims, dims, view, class_num


def main():  #
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--batch-size', type=int, default=256, metavar='N',
                        help='input batch size for training [default: 100]')
    parser.add_argument('--epochs', type=int, default=30, metavar='N',
                        help='number of epochs to train [default: 500]')
    parser.add_argument('--pretrain_epochs', type=int, default=50, metavar='N',
                        help='number of epochs to train [default: 500]')
    parser.add_argument('--annealing-epochs', type=int, default=50, metavar='N',
                        help='number of epochs to train [default: 500]')
    parser.add_argument('--lr', type=float, default=0.001, metavar='LR',
                        help='learning rate [default: 1e-3]')
    parser.add_argument('--patience', type=int, default=30, metavar='LR',
                        help='parameter of Earlystopping [default: 30]')
    parser.add_argument('--log-interval', type=int, default=5, metavar='N',
                        help='how many batches to wait before logging training status [default: 10]')
    parser.add_argument('--cuda', action='store_true', default=True,
                        help='enables CUDA training [default: False]')

    parser.add_argument('--missing-rate', type=float, default=0.4, metavar='LR',
                        help='missingrate [default: 0]')
    parser.add_argument('--dataset', type=str, default='scene15',
                        help='Name of the dataset to use')

    parser.add_argument('--seed', type=int, default=999)

    parser.add_argument('--n-sample', type=int, default=10, metavar='LR',
                        help='times of sampling [default: 10]')
    parser.add_argument('--k', type=int, default=1, metavar='LR',
                        help='number of neighbors [default: 0]')
    parser.add_argument('--k_test', type=int, default=10, metavar='LR',
                        help='number of neighbors [default: 0]')
    parser.add_argument('--if-mean', type=int, default=0, metavar='LR',
                        help='if mean [default: True]')
    parser.add_argument('--latent-dim', type=int, default=128, metavar='LR',
                        help='latent layer dimension [default: True]')
    args = parser.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    # seed = 999
    # setup_seed(seed)

    seed = args.seed
    torch.manual_seed(seed)

    args.classifier_dims, dims, view_num, class_num = load_data(args.dataset)
    dataset = args.dataset + '.mat'
    X, Y, Sn = read_mymat('/mnt/share/zlp/data/', dataset, ['X', 'Y'], args.missing_rate, seed)
    partition = build_ad_dataset(Y, p=0.8, seed=seed)

    X = process_data(X, view_num)
    Sn_train = Sn[partition['train']]
    X_train = [X[v][partition['train']] for v in range(view_num)]
    Y_train = Y[partition['train']]

    train_loader = DataLoader(dataset=partial_mv_dataset(X_train, Sn_train, Y_train), batch_size=args.batch_size,
                              shuffle=True, num_workers=6,
                              collate_fn=partial_mv_tabular_collate)

    model = UGC(class_num, view_num, args.classifier_dims, args.annealing_epochs)
    optimizer = optim.Adam(model.parameters(), lr=args.lr, weight_decay=1e-5)
    trans_model = VTN(view_num, dims, 100).to(device)
    optimizer_vtn = optim.Adam(trans_model.parameters(), lr=args.lr, weight_decay=1e-5)
    criterion = nn.MSELoss()
    if args.cuda:
        model.cuda()



    def test(epoch, dataloader):
        model.eval()
        data_num, correct_num = 0, 0
        for batch_idx, (data, target) in enumerate(dataloader):
            for v_num in range(len(data)):
                data[v_num] = Variable(data[v_num].float().cuda())
            target = Variable(target.long().cuda())
            data_num += target.size(0)
            with torch.no_grad():
                evidence, evidences = model(data, target, epoch, batch_idx, data, 1)
                _, predicted = torch.max(evidences.data, 1)
                list_ = predicted.detach().cpu().numpy().tolist()
                most_ = Counter(list_).most_common(1)[0][0]
                if most_ == target[0]:
                    correct_num += 1
        data_num = int(data_num / args.n_sample)
        acc = correct_num / data_num
        print("total_num：", data_num)
        print('====> accuracy：', acc)
        return acc

    def train(epoch):
        model.train()
        loss_meter = AverageMeter()

        for batch_idx, (data, sn, target) in enumerate(train_loader):
            data_float = [d.float().cuda() for d in data]
            data_double = [d.double().cuda() for d in data]

            target = target.long().cuda()
            sn = sn.long().cuda()

            optimizer.zero_grad()
            optimizer_vtn.zero_grad()
            total_loss = 0.0
            loss_tmc, loss_incomplete, loss_nng, total_loss_invtn, total_loss_vtn = (0.0, 0.0, 0.0, 0.0, 0.0)

            # complete data
            x_complete_indices = np.where(np.sum(sn.cpu().numpy(), axis=1) == view_num)[0]
            if len(x_complete_indices) > 0:
                x_complete_float = [data_float[v][x_complete_indices] for v in range(view_num)]
                y_complete = target[x_complete_indices]
                # TMC
                evidences_complete, evidence_a, loss_tmc = model(x_complete_float, y_complete, epoch, batch_idx,
                                                                 sn[x_complete_indices])


                for i in range(view_num):
                    for j in range(i, view_num):
                        if i != j:
                            output_0 = trans_model(i, j + i * view_num, x_complete_float[i])
                            loss_vtn = criterion(output_0, x_complete_float[j])
                            output_1 = trans_model(j, i + j * view_num, x_complete_float[j])
                            loss_vtn += criterion(output_1, x_complete_float[i])
                            total_loss_vtn += loss_vtn

            # incomplete data
            x_incomplete_indices = np.where(np.sum(sn.cpu().numpy(), axis=1) != view_num)[0]
            if len(x_incomplete_indices) > 0:
                x_incomplete_float = [data_float[v][x_incomplete_indices] for v in range(view_num)]
                x_incomplete_double = [data_double[v][x_incomplete_indices] for v in range(view_num)]
                y_incomplete = target[x_incomplete_indices]
                neighbors = select_top_k_neighbors(data_float, target, args.k)  #

                missing_views = []
                for idx in x_incomplete_indices:
                    missing = np.where(sn[idx, :].cpu().numpy() == 0)[0]
                    missing_views.append(missing)

                reconstructed_views = [[] for _ in range(view_num)]

                for internal_idx, (sample_idx, missing) in enumerate(zip(x_incomplete_indices, missing_views)):
                    translist_tempt = [[] for _ in range(view_num)]
                    present_views = np.where(sn[sample_idx, :].cpu().numpy() == 1)[0]
                    for missing_view in missing:
                        translist_tempt[missing_view] = []
                        for present_view in present_views:
                            x_trans = x_incomplete_double[present_view][internal_idx].unsqueeze(0)
                            output = trans_model(present_view, missing_view + present_view * view_num, x_trans)
                            translist_tempt[missing_view].append(output)

                    for missing_view in missing:
                        if len(present_views) == 1:
                            sum_outputs = translist_tempt[missing_view]
                            reconstructed_views[missing_view].append(sum_outputs[0])
                        else:
                            u = []
                            for output in translist_tempt[missing_view]:
                                u.append(model.collect_t(output.float(), missing_view))
                            u = torch.tensor(u)
                            inverse_weights = (1 / u).to(device)
                            normalized_weights = inverse_weights / torch.sum(inverse_weights).to(device)
                            # 使用广播机制对输出进行加权求和
                            weighted_outputs = normalized_weights.view(-1, 1) * torch.stack(
                                translist_tempt[missing_view]).to(device)
                            sum_outputs = torch.sum(weighted_outputs, dim=0)  # 对加权后的输出求和
                            a = sum_outputs[0].reshape(1, -1)
                            reconstructed_views[missing_view].append(a)

                complete_samples = [[] for _ in range(view_num)]
                index_map = {view_id: 0 for view_id in range(view_num)}
                for internal_idx, (sample_idx, missing) in enumerate(zip(x_incomplete_indices, missing_views)):
                    complete_sample = []
                    for view_id in range(view_num):
                        if view_id in missing:
                            reconstructed_view = reconstructed_views[view_id][index_map[view_id]]
                            index_map[view_id] += 1
                            complete_sample.append(reconstructed_view.float())

                        else:
                            present_view = x_incomplete_double[view_id][internal_idx].unsqueeze(0)
                            complete_sample.append(present_view.float())
                    for view_id in range(view_num):
                        complete_samples[view_id].append(complete_sample[view_id])


                complete_samples = [torch.cat(view, dim=0) for view in complete_samples]


                if len(complete_samples) > 0:
                    _, _, loss_incomplete = model(complete_samples, y_incomplete, epoch,
                                                  batch_idx, sn[x_incomplete_indices])

                    for i in range(view_num):
                        for j in range(i, view_num):
                            if i != j:
                                output_0 = trans_model(i, j + i * view_num, complete_samples[i])
                                loss_invtn = criterion(output_0, complete_samples[j])
                                output_1 = trans_model(j, i + j * view_num, complete_samples[j])
                                loss_invtn += criterion(output_1, complete_samples[i])
                                total_loss_invtn += loss_invtn

                    zs = []
                    zs_all = []  #
                    for i in range(view_num):
                        z = trans_model.encode(i, complete_samples[i])
                        zs.append(z)
                        z_a = trans_model.encode(i, data_float[i])  #
                        zs_all.append(z_a)  #

                    for view in range(view_num):
                        for i in range(len(complete_samples[view])):
                            if view in missing_views[i]:
                                present_views = np.where(sn[x_incomplete_indices[i], :].cpu().numpy() == 1)[0]
                                for present_view in present_views:
                                    for neighbor in neighbors[present_view][x_incomplete_indices[i]]:
                                        dist = F.pairwise_distance(zs[view][i].unsqueeze(0),
                                                                   zs_all[view][neighbor].unsqueeze(0))
                                        loss_nng += torch.mean(dist)

                    loss_nng /= (view_num * len(complete_samples) * neighbors[0].shape[1])
                    # total_loss += loss_nng


            total_loss = loss_tmc + loss_incomplete + loss_nng + total_loss_invtn + total_loss_vtn

            total_loss.backward()
            loss_meter.update(total_loss.item())
            optimizer.step()
            optimizer_vtn.step()

        print('Train Epoch: {} [{}/{} ({:.0f}%)]\tLoss: {:.6f}'.format(
            epoch, batch_idx * len(data[0]), len(train_loader.dataset),
                   100. * batch_idx / len(train_loader), loss_meter.avg))

        return loss_meter.avg

    early_stopping = EarlyStopping(patience=args.patience, verbose=True)


    for epoch in range(1, args.epochs + 1):
        loss = train(epoch)
        early_stopping(loss * (-1), model)
        if early_stopping.early_stop:
            print("Early stopping")
            break
    X_test, Y_test = get_samples(x=X,
                                 y=Y,
                                 sn=Sn,
                                 test_index=partition['test'],
                                 n_sample=args.n_sample,
                                 seed=seed,
                                 device=device,
                                 trans_model=trans_model,
                                 )
    test_batch_size = args.n_sample
    test_loader = DataLoader(dataset=mv_dataset(X_test, Y_test), batch_size=test_batch_size,
                             shuffle=False, num_workers=6,
                             collate_fn=mv_tabular_collate)
    # model = nn.DataParallel(model)
    # model.load_state_dict(torch.load('checkpoint_hand.pt'), False)
    acc = test(epoch, test_loader)


if __name__ == "__main__":
    main()

